# Library_1009
- 10.09 : Login & Register & user & help Page 90% 완성
- 10.09 : 연장& 반납 미완성
- config.php -> dbpassword & dbname에는 각자의 것 적을것

# Library_1029
- 10.29 : Board & Library Css적용
- 10.29 : 반납 남은시간 체크 완성 -> 몇가지 case의 확인이 필요
- 10.29 : 각 도서관 별로 자리 사진 넣기 10% 완성
