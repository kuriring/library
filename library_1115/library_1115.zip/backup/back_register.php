<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="/good/good.css">
<title>Register_Page!_!</title>
</head>
<body>
<h2 style="text-align:center;">This_is_Register_Page_Hello?</h2>
<div style="padding:10px; width:300px; border:2px solid black; margin:auto">
<form method="post" action="register_check.php">
<h3 style="text-align:center;">Register_Field</h3>
ID</br><input type="text" name="id"></br>
PASSWORD</br><input type="password" name="password"></br>
PASSWORD_R</br><input type="password" name="password_r"></br>
<h4>Check_your_ex</h4>
Man<input type="radio" name="ex" value ="man">
Women<input type="radio" name="ex" value="women"></br></br>
<input type="submit" value="Register">
</form>
</div>
</body>
</html>
